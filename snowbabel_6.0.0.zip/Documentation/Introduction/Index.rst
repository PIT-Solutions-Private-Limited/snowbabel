﻿.. ==================================================
.. FOR YOUR INFORMATION
.. --------------------------------------------------
.. -*- coding: utf-8 -*- with BOM.

.. include:: ../Includes.txt


What does it do?
================

Snowbabel is a translation Extension. Snowflake productions gmbh was the pioneers of this extension and handed over this to PIT Solutions Pvt Ltd in 2016 and sponsored by BIBUS AG.
This extension provides modules to add custom translations to extension language labels and to manage settings.

If you are looking for a handy TYPO3 translation tool, Snowbabel is for you. Powered with angularjs and extbase.

		Please refer our `github page <https://github.com/snowflakech/snowbabel#readme>`_ for in depth info about the usage
